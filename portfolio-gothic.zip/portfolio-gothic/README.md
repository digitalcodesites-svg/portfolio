# Portfólio — Jean Ferreira

Site estático, responsivo, com visual gótico contemporâneo e detalhes em verde fluorescente.

## Publicar no GitHub Pages
1. Crie um repositório público no GitHub.
2. Envie `index.html` para a raiz do repositório.
3. Vá em Settings > Pages > Build and deployment.
4. Escolha Deploy from a branch, `main` e `/ (root)`.
5. Aguarde o link do GitHub Pages aparecer.

## Personalizar
- No fim de `index.html`, edite a lista `skills` para definir seus percentuais reais (os atuais são ilustrativos).
- Atualize as descrições dos projetos e adicione URLs quando estiverem públicos.
- Troque `https://github.com/` pelo link do seu perfil.
- Edite `:root` no CSS para ajustar as cores.

Não é necessário framework, servidor ou instalação.
